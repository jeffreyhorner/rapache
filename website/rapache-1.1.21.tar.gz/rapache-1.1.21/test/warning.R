cat('options()$warn is',getOption('warn'),'\n')
cat('warnings:\n')
print(warnings())
